(function () {
  const canvas = document.getElementById("qr");
  const urlEl = document.getElementById("url");
  const programmeUrl = new URL("index.html", window.location.href).href;

  urlEl.textContent = programmeUrl;

  const qr = qrcode(0, "M");
  qr.addData(programmeUrl);
  qr.make();

  const modules = qr.getModuleCount();
  const size = 1024;
  const scale = size / modules;
  canvas.width = size;
  canvas.height = size;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = "#ffffff";
  ctx.fillRect(0, 0, size, size);
  ctx.fillStyle = "#10151c";
  for (let row = 0; row < modules; row += 1) {
    for (let col = 0; col < modules; col += 1) {
      if (qr.isDark(row, col)) {
        ctx.fillRect(Math.floor(col * scale), Math.floor(row * scale), Math.ceil(scale), Math.ceil(scale));
      }
    }
  }
})();
